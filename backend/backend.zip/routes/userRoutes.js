import express from 'express';
import { registerUser, loginUser, getProfile, updateProfile, bookAppointment, listAppointment, cancelAppointment, paymentPayPal, verifyPayPalPayment, refundCapturedPayment } from '../controllers/userController.js';
import authUser from '../middlewares/authUser.js';
import upload from '../middlewares/multer.js';

const userRouter = express.Router()

userRouter.post('/register', registerUser)
userRouter.post('/login', loginUser)

userRouter.get('/get-profile',authUser ,getProfile)
userRouter.post('/update-profile', upload.single('image'), authUser, updateProfile)
userRouter.post('/book-appointment', authUser, bookAppointment)
userRouter.get('/appointments', authUser, listAppointment)
userRouter.post('/cancel-appointment', authUser, cancelAppointment)

userRouter.post('/payment-paypal',authUser,paymentPayPal,async (req, res) => {
    try {
        // Use the cart information passed from the front-end to calculate the order amount details
        const { cart, appointmentId } = req.body;
        console.log(JSON.stringify(cart))
        console.log(JSON.stringify(appointmentId))

        // Create the order
        const { jsonResponse: orderResponse, httpStatusCode } = await paymentPayPal(cart);
        
        // Proceed with PayPal payment using the created order
        const paymentResponse = await verifyPayPalPayment(req, res, orderResponse); // Assuming paymentPayPal can accept orderResponse

        res.status(httpStatusCode).json(paymentResponse);
    } catch (error) {
        console.error("Failed to process PayPal payment:", error);
        res.status(500).json({ error: "Failed to process PayPal payment." });
    }
});
userRouter.post('/verify-paypal/capture', verifyPayPalPayment, async (req, res) => {
    try {
        const { id} = req.body;
        console.log(id)
        const orderID = id; // Assuming the order ID is in the format ORDER_1234567890
        const { jsonResponse, httpStatusCode } = await verifyPayPalPayment(orderID);
        res.status(httpStatusCode).json(jsonResponse);
    } catch (error) {
        console.error("Failed to create order:", error);
        res.status(500).json({ error: "Failed to capture order." });
    }
})

// refundCapturedPayment route
userRouter.post("/api/payments/refund", refundCapturedPayment,async (req, res) => {
    try {
        const { capturedPaymentId } = req.body;
        const { jsonResponse, httpStatusCode } = await refundCapturedPayment(
            capturedPaymentId
        );
        res.status(httpStatusCode).json(jsonResponse);
    } catch (error) {
        console.error("Failed refund captured payment:", error);
        res.status(500).json({ error: "Failed refund captured payment." });
    }
});

export default userRouter


