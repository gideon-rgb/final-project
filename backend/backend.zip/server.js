import express from 'express';
import cors from 'cors';
import 'dotenv/config'
import connectToDatabase from './config/db.js'
import connectCloudinary from './config/cloudinary.js';
import adminRouter from './routes/adminroute.js';
import doctorRouter from './routes/doctorRoute.js';
import userRouter from './routes/userRoutes.js';
//import paypalRouter from './routes/paypalRoute.js'; // Import the PayPal routes
import bodyParser from "body-parser";

// app config
const app = express();
app.use(bodyParser.json());
const port = process.env.PORT || 4000
connectToDatabase()
connectCloudinary()

// middleware
app.use(express.json());
app.use(cors());

//api endpoints
app.use('/api/admin', adminRouter)
app.use('/api/doctors', doctorRouter)
app.use('/api/user', userRouter)
//app.use('/api/paypal', paypalRouter); // Use the PayPal routes

app.get(' /',(req,res)=> {
    res.send(' API WORKING sussesifuly');
})

//start server
app.listen(port, () => {
    console.log(`Server is running at: http://localhost:${port}`);
});
//th end...................................................................